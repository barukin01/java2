# Java_KDK10_LAB2
**Промышленное программирование. Задание 2**

![Screenshot](screenshot_lab.png)
![Screenshot](screenshot_sql.png)
